<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1626545229525'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/seelmann/Development/Apache/git/studio-release/product/target/products/org.apache.directory.studio.product/linux/gtk/x86_64/ApacheDirectoryStudio'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/seelmann/Development/Apache/git/studio-release/product/target/products/org.apache.directory.studio.product/linux/gtk/x86_64/ApacheDirectoryStudio'/>
  </properties>
</profile>
